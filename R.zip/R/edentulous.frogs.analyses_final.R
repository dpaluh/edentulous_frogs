#Analyses and visualizations for #Paluh et al.: Rampant tooth loss across 200 million years of frog evolution

#RevBayes ancestral state reconstruction visualization for 524 amphibian species
library(ape)
library(geiger)
library(phytools)
library(devtools)
library(RevGadgets)

#read in data
data  <- read.csv("data_dentition_524species.csv", header=T, row.names=1)

#read in Jetz and Pyron 2018 tree
#***Uperoleia_mahonyi was manually added into Jetz and Pyron tree, replacing Uperoleia_micra***
tree <- read.tree("amph_shl_new_Posterior_7238.tre")
#checking match
name.check(tree, data)

#prune tips
species.to.keep <-read.csv("data_dentition_524species.csv", header=T)
pruned.tree<-drop.tip(tree,tree$tip.label[-na.omit(match(species.to.keep[,1],tree$tip.label))])
write.tree(pruned.tree, file = "pruned_tree.phy")
tree <- read.tree("pruned_tree.phy")
name.check(tree, data)

#sorting tips & traits
compare <- treedata(tree, data, sort=TRUE)
data_sorted <- as.data.frame(compare$data)
tree_sorted <- compare$phy
write.tree(tree_sorted, "tree_sorted.tre")
write.csv(data_sorted, "data_sorted.csv")
tree <- read.tree("tree_sorted.tre")
data_sorted <- read.csv("data_sorted.csv", header=T, row.names=1)

#set tip colors
edentulism <- data_sorted$Dentition
edentulism.col<-character(length(data_sorted))
edentulism.col[edentulism=="absent"]<-"firebrick2"
edentulism.col[edentulism=="present"]<-"darkslateblue"

#get node states from RevGadgets
freeK_RJ_tree_file = "ancestral_states_ase_freeK_RJ_edentulism.tree"
#plot RevBayes ancestral states
freeK_RJ <- plot_ancestral_states(freeK_RJ_tree_file, summary_statistic="MAP",
                                  tip_label_size=0.5,
                                  xlim_visible=NULL,
                                  node_label_size=0,
                                  show_posterior_legend=TRUE,
                                  node_size_range=c(1,3),
                                  alpha=0.75)
plot(freeK_RJ)
#extract node states and posterior probabilities 
node_states<-freeK_RJ$data$anc_state_1[525:1047]
pp<-freeK_RJ$data$anc_state_1_pp[525:1047]

#set node colors
mycolnodes<-character(length(node_states))
mycolnodes[node_states=="1"]<-"darkslateblue"
mycolnodes[node_states=="2"]<-"firebrick2"

#plot Figure 2 
par(oma=c(0,0,0,0))
plotTree(tree,ftype="i",lwd=0.2,fsize=0.0001,type="fan",part=1, outline = FALSE)
nodelabels(pch=16, adj=0, col=mycolnodes, cex = 1*as.numeric(pp))
tiplabels(pch=16, col=edentulism.col, cex=0.6)

#plot Figure S1 with tip labels
par(oma=c(0,0,0,0))
plotTree(tree,ftype="i",lwd=0.2,fsize=0.3,type="fan",part=1, outline = FALSE)
nodelabels(pch=16, adj=0, col=mycolnodes, cex = 1*as.numeric(pp))
tiplabels(pch=16, col=edentulism.col, cex=0.6)


#phylogram with time tree
plotTree(tree,ftype="i",lwd=0.2,fsize=0.1,type="phylogram",part=1, outline = FALSE, mar = c(2,1,1,1))
nodelabels(pch=16, adj=0, col=mycolnodes, cex = 0.5*as.numeric(pp))
tiplabels(pch=15, col=edentulism.col, cex=0.1)
axisPhylo(1)


#RevBayes compute posterior probabilities and bayes factors
out_file = "model_comparison_results.txt"
log = read.table("ase_freeK_RJ_edentulism.log", header=TRUE, sep="\t", stringsAsFactors=FALSE)
#compute posterior probabilities
total_samples = length(log$rate_01)
m1_rate_samples = length(which(log$rate_01 == log$rate_10))
m01_irreversible = length(which(log$rate_01 == 0))
m10_irreversible = length(which(log$rate_10 == 0))
m2_rate_samples = total_samples - (m1_rate_samples + m01_irreversible + m10_irreversible)
m2_samples1 = which(log$rate_01 != log$rate_10)
m2_samples = which(log[m2_samples1,]$rate_10 != 0)
mean(log[m2_samples,]$rate_01)
mean(log[m2_samples,]$rate_10)
write("Model posterior probabilities:", file=out_file)
write(paste("01 irreversible: ", round(m01_irreversible / total_samples, 2), sep=""), file=out_file, append=TRUE)
write(paste("10 irreversible: ", round(m10_irreversible / total_samples, 2), sep=""), file=out_file, append=TRUE)
write(paste("1 rate: ", round(m1_rate_samples / total_samples, 2), sep=""), file=out_file, append=TRUE)
write(paste("2 rate: ", round(m2_rate_samples / total_samples, 2), sep=""), file=out_file, append=TRUE)
write("", file=out_file, append=TRUE)







#Dentition and diet data for 267 frog species
library(ape)
library(geiger)
library(phytools)

#read in data
data  <- read.csv("data_diet_267species.csv", header=T, row.names=1)
#read in Jetz and Pyron 2018 tree
tree <- read.tree("amph_shl_new_Posterior_7238.tre")

#prune tips
species.to.keep <-read.csv("data_diet_267species.csv", header=T)
pruned.tree<-drop.tip(tree,tree$tip.label[-na.omit(match(species.to.keep[,1],tree$tip.label))])
write.tree(pruned.tree, file = "pruned_tree.phy")
tree <- read.tree("pruned_tree.phy")
name.check(tree, data)

#sorting tips & traits
compare <- treedata(tree, data, sort=TRUE)
data_sorted <- as.data.frame(compare$data)
tree_sorted <- compare$phy
write.tree(tree_sorted, "tree_sorted.tre")
write.csv(data_sorted, "data_sorted.csv")
tree <- read.tree("tree_sorted.tre")

#stochastic character map (simmap) of dentition states
teeth<-as.factor(setNames(data_sorted[,2],rownames(data_sorted)))
tooth.trees<-make.simmap(tree,teeth,nsim=100)
obj<-densityMap(tooth.trees,states=c("absent","present"),plot=FALSE)
n<-length(obj$cols)
obj$cols[1:n]<-colorRampPalette(c("firebrick2","darkslateblue"), space="Lab")(n)

#set tip colors
diet <- data_sorted$Diet_combined
diet.col<-character(length(data_sorted))
diet.col[diet=="microphagous"]<-"black"
diet.col[diet=="generalist"]<-"white"

#Plot Figure 3
plot(obj,type="fan",res=1000,lwd=1.5,outline=FALSE,fsize=c(0.001,0.0001),legend=FALSE)
tiplabels(pch=21, col="black", bg=diet.col, cex=0.75)

#Plot Figure S2 with tip labels
par(oma=c(0,0,0,0))
plot(obj,type="fan",res=1000,lwd=1.5,outline=FALSE,fsize=c(0.4),legend=FALSE)
par(oma=c(0.3,0.3,0.3,0.3))
tiplabels(pch=21, col="black", bg=diet.col, cex=0.75)







#Body and skull measurement analyses for 423 frog species
data  <- read.csv("data_measurements_423species.csv", header=T, row.names=1)

relative.jaw.length <- data$Jaw_length/data$Skull_length
data$relative.jaw.length <- data$Jaw_length/data$Skull_length

library(ggplot2)
#Plot Figure 4 panels
#Relative jaw length histogram
mu <- ddply(data, "Dentition", summarise, grp.mean=mean(relative.jaw.length))
head(mu)
p<-ggplot(data, aes(x=(relative.jaw.length), fill=Dentition, color=Dentition)) +
  geom_histogram(position="identity", alpha=0.5, binwidth=0.01)
p
p+geom_vline(data=mu, aes(xintercept=grp.mean, color=Dentition),
             linetype="dashed")
#SVL histogram
mu <- ddply(data, "Dentition", summarise, grp.mean=mean(SVL))
head(mu)
p<-ggplot(data, aes(x=(SVL), fill=Dentition, color=Dentition)) +
  geom_histogram(position="identity", alpha=0.5, binwidth=3)
p
p+geom_vline(data=mu, aes(xintercept=grp.mean, color=Dentition),
             linetype="dashed")


library(ape)
library(geiger)
tree <- read.tree("amph_shl_new_Posterior_7238.tre")
#prune tips
species.to.keep <-read.csv("data_measurements_423species.csv", header=T)
pruned.tree<-drop.tip(tree,tree$tip.label[-na.omit(match(species.to.keep[,1],tree$tip.label))])
write.tree(pruned.tree, file = "pruned_tree.phy")
tree <- read.tree("pruned_tree.phy")
name.check(tree, data)

#sorting tips & traits
compare <- treedata(tree, data, sort=TRUE)
data_sorted <- as.data.frame(compare$data)
tree_sorted <- compare$phy
write.tree(tree_sorted, "tree_sorted.tre")
write.csv(data_sorted, "data_sorted.csv")
tree <- read.tree("tree_sorted.tre")
data <-read.csv("data_sorted.csv", header=T, row.names = 1)

#Phylogenetic logisitic regressions
library(phylolm)
fit_SVL = phyloglm(Dentition_1~log(SVL),phy=tree,data=data,boot=1000, method = "logistic_MPLE", btol = 10, log.alpha.bound = 10)
summary(fit_SVL)

fit_JL = phyloglm(Dentition_1~log(relative.jaw.length),phy=tree,data=data,boot=1000, method = "logistic_MPLE", btol = 10, log.alpha.bound = 10)
summary(fit_JL)
